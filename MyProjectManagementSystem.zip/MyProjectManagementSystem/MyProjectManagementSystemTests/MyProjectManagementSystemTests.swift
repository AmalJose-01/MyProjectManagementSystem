//
//  MyProjectManagementSystemTests.swift
//  MyProjectManagementSystemTests
//
//  Created by Amal Jose on 12/3/2025.
//

import Testing
@testable import MyProjectManagementSystem

struct MyProjectManagementSystemTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
